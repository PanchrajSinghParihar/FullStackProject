# Vehicle Service Booking System

A comprehensive vehicle service management system built with React frontend, Spring Boot backend, and MySQL database.

## 🚗 Features

### Booking Panel
- Customer registration and authentication
- Vehicle registration and management
- Service booking with slot validation
- Real-time availability checking
- Booking confirmation and notifications

### Mechanic Portal
- Mechanic authentication and dashboard
- Service assignment and management
- Work progress tracking
- Service completion and reporting
- Parts inventory management

### Service History
- Complete service history for vehicles
- Service details and maintenance logs
- Customer feedback and ratings
- Service reminders and notifications
- Export functionality for records

## 🛠️ Tech Stack

### Frontend
- **React 18** - Modern UI framework
- **TypeScript** - Type safety
- **Tailwind CSS** - Styling
- **React Router** - Navigation
- **Axios** - HTTP client
- **React Hook Form** - Form management
- **React Query** - Data fetching

### Backend
- **Spring Boot 3** - REST API
- **Spring Security** - Authentication & Authorization
- **Spring Data JPA** - Database operations
- **MySQL 8** - Database
- **JWT** - Token-based authentication
- **Maven** - Dependency management

## 📁 Project Structure

```
finalProject/
├── frontend/                 # React application
│   ├── src/
│   │   ├── components/      # Reusable components
│   │   ├── pages/          # Page components
│   │   ├── services/       # API services
│   │   ├── hooks/          # Custom hooks
│   │   ├── types/          # TypeScript types
│   │   └── utils/          # Utility functions
│   └── public/
├── backend/                 # Spring Boot application
│   ├── src/main/java/
│   │   ├── controller/     # REST controllers
│   │   ├── service/        # Business logic
│   │   ├── repository/     # Data access layer
│   │   ├── model/          # Entity models
│   │   ├── dto/            # Data transfer objects
│   │   ├── config/         # Configuration classes
│   │   └── security/       # Security configuration
│   └── src/main/resources/
└── database/               # Database scripts
    ├── schema.sql          # Database schema
    └── data.sql           # Sample data
```

## 🚀 Getting Started

### Prerequisites
- Node.js 18+
- Java 17+
- MySQL 8.0+
- Maven 3.6+

### Installation

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd finalProject
   ```

2. **Set up the database**
   ```bash
   # Create MySQL database
   mysql -u root -p
   CREATE DATABASE vehicle_service_db;
   USE vehicle_service_db;
   
   # Run schema and data scripts
   source database/schema.sql
   source database/data.sql
   ```

3. **Configure backend**
   ```bash
   cd backend
   # Update application.properties with your database credentials
   mvn clean install
   mvn spring-boot:run
   ```

4. **Start frontend**
   ```bash
   cd frontend
   npm install
   npm start
   ```

## 🔐 Authentication

The system supports three user roles:
- **Customer** - Can book services, view history, provide feedback
- **Mechanic** - Can view assigned services, update progress, complete services
- **Admin** - Can manage users, services, and system settings

## 📊 API Endpoints

### Authentication
- `POST /api/auth/login` - User login
- `POST /api/auth/register` - User registration
- `POST /api/auth/refresh` - Refresh JWT token

### Booking
- `GET /api/bookings` - Get all bookings
- `POST /api/bookings` - Create new booking
- `GET /api/bookings/{id}` - Get booking details
- `PUT /api/bookings/{id}` - Update booking
- `DELETE /api/bookings/{id}` - Cancel booking

### Services
- `GET /api/services` - Get available services
- `POST /api/services` - Create new service
- `PUT /api/services/{id}` - Update service
- `DELETE /api/services/{id}` - Delete service

### Vehicles
- `GET /api/vehicles` - Get user vehicles
- `POST /api/vehicles` - Register new vehicle
- `PUT /api/vehicles/{id}` - Update vehicle
- `DELETE /api/vehicles/{id}` - Delete vehicle

### Feedback
- `GET /api/feedback` - Get service feedback
- `POST /api/feedback` - Submit feedback
- `PUT /api/feedback/{id}` - Update feedback

## 🧪 Testing

### Backend Tests
```bash
cd backend
mvn test
```

### Frontend Tests
```bash
cd frontend
npm test
```

## 📝 License

This project is licensed under the MIT License.

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Commit your changes
4. Push to the branch
5. Create a Pull Request 