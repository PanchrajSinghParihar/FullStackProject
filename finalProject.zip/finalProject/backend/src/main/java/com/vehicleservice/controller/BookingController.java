package com.vehicleservice.controller;

import com.vehicleservice.model.Booking;
import com.vehicleservice.model.ServiceSlot;
import com.vehicleservice.service.BookingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/bookings")
@CrossOrigin(origins = "http://localhost:3000")
public class BookingController {
    
    @Autowired
    private BookingService bookingService;
    
    @GetMapping
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<List<Booking>> getAllBookings() {
        List<Booking> bookings = bookingService.getAllBookings();
        return ResponseEntity.ok(bookings);
    }
    
    @GetMapping("/{id}")
    public ResponseEntity<Booking> getBookingById(@PathVariable Long id) {
        Optional<Booking> booking = bookingService.getBookingById(id);
        return booking.map(ResponseEntity::ok)
                     .orElse(ResponseEntity.notFound().build());
    }
    
    @GetMapping("/customer/{customerId}")
    @PreAuthorize("hasRole('CUSTOMER') or hasRole('ADMIN')")
    public ResponseEntity<List<Booking>> getBookingsByCustomerId(@PathVariable Long customerId) {
        List<Booking> bookings = bookingService.getBookingsByCustomerId(customerId);
        return ResponseEntity.ok(bookings);
    }
    
    @GetMapping("/mechanic/{mechanicId}")
    @PreAuthorize("hasRole('MECHANIC') or hasRole('ADMIN')")
    public ResponseEntity<List<Booking>> getBookingsByMechanicId(@PathVariable Long mechanicId) {
        List<Booking> bookings = bookingService.getBookingsByMechanicId(mechanicId);
        return ResponseEntity.ok(bookings);
    }
    
    @GetMapping("/customer/{customerId}/active")
    @PreAuthorize("hasRole('CUSTOMER') or hasRole('ADMIN')")
    public ResponseEntity<List<Booking>> getActiveBookingsByCustomerId(@PathVariable Long customerId) {
        List<Booking> bookings = bookingService.getActiveBookingsByCustomerId(customerId);
        return ResponseEntity.ok(bookings);
    }
    
    @GetMapping("/mechanic/{mechanicId}/active")
    @PreAuthorize("hasRole('MECHANIC') or hasRole('ADMIN')")
    public ResponseEntity<List<Booking>> getActiveBookingsByMechanicId(@PathVariable Long mechanicId) {
        List<Booking> bookings = bookingService.getActiveBookingsByMechanicId(mechanicId);
        return ResponseEntity.ok(bookings);
    }
    
    @PostMapping
    @PreAuthorize("hasRole('CUSTOMER') or hasRole('ADMIN')")
    public ResponseEntity<Booking> createBooking(@RequestBody Booking booking) {
        try {
            Booking createdBooking = bookingService.createBooking(booking);
            return ResponseEntity.ok(createdBooking);
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().build();
        }
    }
    
    @PutMapping("/{id}")
    @PreAuthorize("hasRole('MECHANIC') or hasRole('ADMIN')")
    public ResponseEntity<Booking> updateBooking(@PathVariable Long id, @RequestBody Booking bookingDetails) {
        Booking updatedBooking = bookingService.updateBooking(id, bookingDetails);
        if (updatedBooking != null) {
            return ResponseEntity.ok(updatedBooking);
        }
        return ResponseEntity.notFound().build();
    }
    
    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('CUSTOMER') or hasRole('ADMIN')")
    public ResponseEntity<Void> cancelBooking(@PathVariable Long id) {
        boolean cancelled = bookingService.cancelBooking(id);
        if (cancelled) {
            return ResponseEntity.ok().build();
        }
        return ResponseEntity.notFound().build();
    }
    
    @PostMapping("/{id}/confirm")
    @PreAuthorize("hasRole('MECHANIC') or hasRole('ADMIN')")
    public ResponseEntity<Void> confirmBooking(@PathVariable Long id) {
        boolean confirmed = bookingService.confirmBooking(id);
        if (confirmed) {
            return ResponseEntity.ok().build();
        }
        return ResponseEntity.notFound().build();
    }
    
    @PostMapping("/{id}/start")
    @PreAuthorize("hasRole('MECHANIC') or hasRole('ADMIN')")
    public ResponseEntity<Void> startService(@PathVariable Long id) {
        boolean started = bookingService.startService(id);
        if (started) {
            return ResponseEntity.ok().build();
        }
        return ResponseEntity.notFound().build();
    }
    
    @PostMapping("/{id}/complete")
    @PreAuthorize("hasRole('MECHANIC') or hasRole('ADMIN')")
    public ResponseEntity<Void> completeService(@PathVariable Long id) {
        boolean completed = bookingService.completeService(id);
        if (completed) {
            return ResponseEntity.ok().build();
        }
        return ResponseEntity.notFound().build();
    }
    
    @GetMapping("/slots/available")
    public ResponseEntity<List<ServiceSlot>> getAvailableSlots(
            @RequestParam LocalDate date,
            @RequestParam Long mechanicId) {
        List<ServiceSlot> slots = bookingService.getAvailableSlots(date, mechanicId);
        return ResponseEntity.ok(slots);
    }
    
    @GetMapping("/slots/validate")
    public ResponseEntity<Boolean> validateSlotAvailability(
            @RequestParam Long slotId,
            @RequestParam LocalDate date,
            @RequestParam String time) {
        boolean isAvailable = bookingService.isSlotAvailable(slotId, date, java.time.LocalTime.parse(time));
        return ResponseEntity.ok(isAvailable);
    }
    
    @GetMapping("/date-range")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<List<Booking>> getBookingsByDateRange(
            @RequestParam LocalDate startDate,
            @RequestParam LocalDate endDate) {
        List<Booking> bookings = bookingService.getBookingsByDateRange(startDate, endDate);
        return ResponseEntity.ok(bookings);
    }
    
    @GetMapping("/customer/{customerId}/recent")
    @PreAuthorize("hasRole('CUSTOMER') or hasRole('ADMIN')")
    public ResponseEntity<List<Booking>> getRecentBookingsByCustomer(
            @PathVariable Long customerId,
            @RequestParam LocalDate startDate) {
        List<Booking> bookings = bookingService.getRecentBookingsByCustomer(customerId, startDate);
        return ResponseEntity.ok(bookings);
    }
} 