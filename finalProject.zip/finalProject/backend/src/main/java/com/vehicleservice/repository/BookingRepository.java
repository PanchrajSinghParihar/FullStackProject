package com.vehicleservice.repository;

import com.vehicleservice.model.Booking;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Repository
public interface BookingRepository extends JpaRepository<Booking, Long> {
    
    List<Booking> findByCustomerId(Long customerId);
    
    List<Booking> findByMechanicId(Long mechanicId);
    
    List<Booking> findByStatus(Booking.BookingStatus status);
    
    List<Booking> findByCustomerIdAndStatus(Long customerId, Booking.BookingStatus status);
    
    List<Booking> findByMechanicIdAndStatus(Long mechanicId, Booking.BookingStatus status);
    
    List<Booking> findByBookingDate(LocalDate bookingDate);
    
    List<Booking> findByBookingDateBetween(LocalDate startDate, LocalDate endDate);
    
    @Query("SELECT b FROM Booking b WHERE b.customer.id = :customerId AND b.status IN ('PENDING', 'CONFIRMED', 'IN_PROGRESS')")
    List<Booking> findActiveBookingsByCustomerId(@Param("customerId") Long customerId);
    
    @Query("SELECT b FROM Booking b WHERE b.mechanic.id = :mechanicId AND b.status IN ('CONFIRMED', 'IN_PROGRESS')")
    List<Booking> findActiveBookingsByMechanicId(@Param("mechanicId") Long mechanicId);
    
    @Query("SELECT b FROM Booking b WHERE b.vehicle.id = :vehicleId ORDER BY b.bookingDate DESC")
    List<Booking> findBookingsByVehicleId(@Param("vehicleId") Long vehicleId);
    
    @Query("SELECT COUNT(b) FROM Booking b WHERE b.mechanic.id = :mechanicId AND b.bookingDate = :date AND b.status IN ('CONFIRMED', 'IN_PROGRESS')")
    long countActiveBookingsByMechanicAndDate(@Param("mechanicId") Long mechanicId, @Param("date") LocalDate date);
    
    @Query("SELECT b FROM Booking b WHERE b.slot.id = :slotId")
    Optional<Booking> findBySlotId(@Param("slotId") Long slotId);
    
    @Query("SELECT b FROM Booking b WHERE b.bookingDate >= :startDate AND b.bookingDate <= :endDate ORDER BY b.bookingDate DESC")
    List<Booking> findBookingsInDateRange(@Param("startDate") LocalDate startDate, @Param("endDate") LocalDate endDate);
    
    @Query("SELECT b FROM Booking b WHERE b.customer.id = :customerId AND b.bookingDate >= :startDate ORDER BY b.bookingDate DESC")
    List<Booking> findRecentBookingsByCustomer(@Param("customerId") Long customerId, @Param("startDate") LocalDate startDate);
} 