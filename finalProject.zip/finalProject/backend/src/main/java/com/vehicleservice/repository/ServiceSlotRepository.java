package com.vehicleservice.repository;

import com.vehicleservice.model.ServiceSlot;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface ServiceSlotRepository extends JpaRepository<ServiceSlot, Long> {
    
    List<ServiceSlot> findByMechanicId(Long mechanicId);
    
    List<ServiceSlot> findByDate(LocalDate date);
    
    List<ServiceSlot> findByMechanicIdAndDate(Long mechanicId, LocalDate date);
    
    List<ServiceSlot> findByIsAvailableTrue();
    
    List<ServiceSlot> findByMechanicIdAndIsAvailableTrue(Long mechanicId);
    
    @Query("SELECT s FROM ServiceSlot s WHERE s.mechanic.id = :mechanicId AND s.date = :date AND s.isAvailable = true")
    List<ServiceSlot> findAvailableSlotsByDateAndMechanic(@Param("date") LocalDate date, @Param("mechanicId") Long mechanicId);
    
    @Query("SELECT s FROM ServiceSlot s WHERE s.date >= :startDate AND s.date <= :endDate AND s.isAvailable = true")
    List<ServiceSlot> findAvailableSlotsInDateRange(@Param("startDate") LocalDate startDate, @Param("endDate") LocalDate endDate);
    
    @Query("SELECT s FROM ServiceSlot s WHERE s.mechanic.id = :mechanicId AND s.date >= :startDate ORDER BY s.date, s.startTime")
    List<ServiceSlot> findSlotsByMechanicAndDateRange(@Param("mechanicId") Long mechanicId, @Param("startDate") LocalDate startDate);
} 