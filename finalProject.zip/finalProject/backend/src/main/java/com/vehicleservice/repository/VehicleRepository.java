package com.vehicleservice.repository;

import com.vehicleservice.model.Vehicle;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface VehicleRepository extends JpaRepository<Vehicle, Long> {
    
    List<Vehicle> findByUserId(Long userId);
    
    List<Vehicle> findByUserIdAndIsActiveTrue(Long userId);
    
    Optional<Vehicle> findByLicensePlate(String licensePlate);
    
    Optional<Vehicle> findByVin(String vin);
    
    boolean existsByLicensePlate(String licensePlate);
    
    boolean existsByVin(String vin);
    
    @Query("SELECT v FROM Vehicle v WHERE v.user.id = :userId AND v.isActive = true")
    List<Vehicle> findActiveVehiclesByUserId(@Param("userId") Long userId);
    
    @Query("SELECT v FROM Vehicle v WHERE v.make LIKE %:searchTerm% OR v.model LIKE %:searchTerm% OR v.licensePlate LIKE %:searchTerm%")
    List<Vehicle> searchVehicles(@Param("searchTerm") String searchTerm);
} 