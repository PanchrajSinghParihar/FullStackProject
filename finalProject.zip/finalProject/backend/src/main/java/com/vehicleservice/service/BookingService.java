package com.vehicleservice.service;

import com.vehicleservice.model.Booking;
import com.vehicleservice.model.ServiceSlot;
import com.vehicleservice.model.User;
import com.vehicleservice.model.Vehicle;
import com.vehicleservice.repository.BookingRepository;
import com.vehicleservice.repository.ServiceSlotRepository;
import com.vehicleservice.repository.UserRepository;
import com.vehicleservice.repository.VehicleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class BookingService {
    
    @Autowired
    private BookingRepository bookingRepository;
    
    @Autowired
    private ServiceSlotRepository serviceSlotRepository;
    
    @Autowired
    private UserRepository userRepository;
    
    @Autowired
    private VehicleRepository vehicleRepository;
    
    @Autowired
    private NotificationService notificationService;
    
    public List<Booking> getAllBookings() {
        return bookingRepository.findAll();
    }
    
    public Optional<Booking> getBookingById(Long id) {
        return bookingRepository.findById(id);
    }
    
    public List<Booking> getBookingsByCustomerId(Long customerId) {
        return bookingRepository.findByCustomerId(customerId);
    }
    
    public List<Booking> getBookingsByMechanicId(Long mechanicId) {
        return bookingRepository.findByMechanicId(mechanicId);
    }
    
    public List<Booking> getActiveBookingsByCustomerId(Long customerId) {
        return bookingRepository.findActiveBookingsByCustomerId(customerId);
    }
    
    public List<Booking> getActiveBookingsByMechanicId(Long mechanicId) {
        return bookingRepository.findActiveBookingsByMechanicId(mechanicId);
    }
    
    public Booking createBooking(Booking booking) {
        // Validate slot availability
        if (booking.getSlot() != null) {
            if (!isSlotAvailable(booking.getSlot().getId(), booking.getBookingDate(), booking.getPreferredTime())) {
                throw new RuntimeException("Selected slot is not available");
            }
        }
        
        // Set initial status
        booking.setStatus(Booking.BookingStatus.PENDING);
        
        // Calculate total price
        if (booking.getServiceType() != null) {
            booking.setTotalPrice(booking.getServiceType().getBasePrice());
        }
        
        Booking savedBooking = bookingRepository.save(booking);
        
        // Send notification
        notificationService.sendBookingConfirmation(savedBooking);
        
        return savedBooking;
    }
    
    public Booking updateBooking(Long id, Booking bookingDetails) {
        Optional<Booking> existingBooking = bookingRepository.findById(id);
        if (existingBooking.isPresent()) {
            Booking booking = existingBooking.get();
            
            // Update fields
            if (bookingDetails.getStatus() != null) {
                booking.setStatus(bookingDetails.getStatus());
            }
            if (bookingDetails.getMechanic() != null) {
                booking.setMechanic(bookingDetails.getMechanic());
            }
            if (bookingDetails.getSlot() != null) {
                booking.setSlot(bookingDetails.getSlot());
            }
            if (bookingDetails.getNotes() != null) {
                booking.setNotes(bookingDetails.getNotes());
            }
            if (bookingDetails.getTotalPrice() != null) {
                booking.setTotalPrice(bookingDetails.getTotalPrice());
            }
            
            return bookingRepository.save(booking);
        }
        return null;
    }
    
    public boolean cancelBooking(Long id) {
        Optional<Booking> booking = bookingRepository.findById(id);
        if (booking.isPresent()) {
            Booking b = booking.get();
            b.setStatus(Booking.BookingStatus.CANCELLED);
            bookingRepository.save(b);
            
            // Free up the slot
            if (b.getSlot() != null) {
                ServiceSlot slot = b.getSlot();
                slot.setIsAvailable(true);
                serviceSlotRepository.save(slot);
            }
            
            // Send cancellation notification
            notificationService.sendBookingCancellation(b);
            
            return true;
        }
        return false;
    }
    
    public boolean confirmBooking(Long id) {
        Optional<Booking> booking = bookingRepository.findById(id);
        if (booking.isPresent()) {
            Booking b = booking.get();
            b.setStatus(Booking.BookingStatus.CONFIRMED);
            bookingRepository.save(b);
            
            // Reserve the slot
            if (b.getSlot() != null) {
                ServiceSlot slot = b.getSlot();
                slot.setIsAvailable(false);
                serviceSlotRepository.save(slot);
            }
            
            // Send confirmation notification
            notificationService.sendBookingConfirmation(b);
            
            return true;
        }
        return false;
    }
    
    public boolean startService(Long id) {
        Optional<Booking> booking = bookingRepository.findById(id);
        if (booking.isPresent()) {
            Booking b = booking.get();
            b.setStatus(Booking.BookingStatus.IN_PROGRESS);
            bookingRepository.save(b);
            
            // Send service start notification
            notificationService.sendServiceStartNotification(b);
            
            return true;
        }
        return false;
    }
    
    public boolean completeService(Long id) {
        Optional<Booking> booking = bookingRepository.findById(id);
        if (booking.isPresent()) {
            Booking b = booking.get();
            b.setStatus(Booking.BookingStatus.COMPLETED);
            bookingRepository.save(b);
            
            // Send completion notification
            notificationService.sendServiceCompletionNotification(b);
            
            return true;
        }
        return false;
    }
    
    public boolean isSlotAvailable(Long slotId, LocalDate date, LocalTime time) {
        Optional<ServiceSlot> slot = serviceSlotRepository.findById(slotId);
        if (slot.isPresent()) {
            ServiceSlot s = slot.get();
            
            // Check if slot is available
            if (!s.getIsAvailable()) {
                return false;
            }
            
            // Check if slot is on the requested date
            if (!s.getDate().equals(date)) {
                return false;
            }
            
            // Check if time falls within slot range
            if (time.isBefore(s.getStartTime()) || time.isAfter(s.getEndTime())) {
                return false;
            }
            
            // Check if mechanic has other bookings at this time
            long conflictingBookings = bookingRepository.countActiveBookingsByMechanicAndDate(s.getMechanic().getId(), date);
            if (conflictingBookings > 0) {
                return false;
            }
            
            return true;
        }
        return false;
    }
    
    public List<ServiceSlot> getAvailableSlots(LocalDate date, Long mechanicId) {
        return serviceSlotRepository.findAvailableSlotsByDateAndMechanic(date, mechanicId);
    }
    
    public List<Booking> getBookingsByDateRange(LocalDate startDate, LocalDate endDate) {
        return bookingRepository.findBookingsInDateRange(startDate, endDate);
    }
    
    public List<Booking> getRecentBookingsByCustomer(Long customerId, LocalDate startDate) {
        return bookingRepository.findRecentBookingsByCustomer(customerId, startDate);
    }
} 