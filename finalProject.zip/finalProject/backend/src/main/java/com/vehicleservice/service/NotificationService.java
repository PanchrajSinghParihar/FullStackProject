package com.vehicleservice.service;

import com.vehicleservice.model.Booking;
import com.vehicleservice.model.Notification;
import com.vehicleservice.model.User;
import com.vehicleservice.repository.NotificationRepository;
import com.vehicleservice.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class NotificationService {
    
    @Autowired
    private NotificationRepository notificationRepository;
    
    @Autowired
    private UserRepository userRepository;
    
    public void sendBookingConfirmation(Booking booking) {
        Notification notification = new Notification();
        notification.setUser(booking.getCustomer());
        notification.setTitle("Booking Confirmed");
        notification.setMessage("Your service booking for " + booking.getVehicle().getMake() + " " + 
                              booking.getVehicle().getModel() + " on " + booking.getBookingDate() + 
                              " has been confirmed.");
        notification.setType(Notification.NotificationType.BOOKING_CONFIRMATION);
        notificationRepository.save(notification);
    }
    
    public void sendBookingCancellation(Booking booking) {
        Notification notification = new Notification();
        notification.setUser(booking.getCustomer());
        notification.setTitle("Booking Cancelled");
        notification.setMessage("Your service booking for " + booking.getVehicle().getMake() + " " + 
                              booking.getVehicle().getModel() + " on " + booking.getBookingDate() + 
                              " has been cancelled.");
        notification.setType(Notification.NotificationType.BOOKING_CONFIRMATION);
        notificationRepository.save(notification);
    }
    
    public void sendServiceStartNotification(Booking booking) {
        Notification notification = new Notification();
        notification.setUser(booking.getCustomer());
        notification.setTitle("Service Started");
        notification.setMessage("Your vehicle service has started. You will be notified when it's completed.");
        notification.setType(Notification.NotificationType.SERVICE_COMPLETION);
        notificationRepository.save(notification);
    }
    
    public void sendServiceCompletionNotification(Booking booking) {
        Notification notification = new Notification();
        notification.setUser(booking.getCustomer());
        notification.setTitle("Service Completed");
        notification.setMessage("Your vehicle service has been completed. Please pick up your vehicle.");
        notification.setType(Notification.NotificationType.SERVICE_COMPLETION);
        notificationRepository.save(notification);
    }
    
    public void sendFeedbackRequest(Booking booking) {
        Notification notification = new Notification();
        notification.setUser(booking.getCustomer());
        notification.setTitle("Feedback Request");
        notification.setMessage("How was your service experience? Please provide your feedback.");
        notification.setType(Notification.NotificationType.FEEDBACK_REQUEST);
        notificationRepository.save(notification);
    }
    
    public void sendSystemNotification(User user, String title, String message) {
        Notification notification = new Notification();
        notification.setUser(user);
        notification.setTitle(title);
        notification.setMessage(message);
        notification.setType(Notification.NotificationType.SYSTEM);
        notificationRepository.save(notification);
    }
    
    public void sendBookingReminder(Booking booking) {
        Notification notification = new Notification();
        notification.setUser(booking.getCustomer());
        notification.setTitle("Service Reminder");
        notification.setMessage("Reminder: You have a service appointment tomorrow at " + 
                              booking.getPreferredTime() + " for your " + 
                              booking.getVehicle().getMake() + " " + booking.getVehicle().getModel());
        notification.setType(Notification.NotificationType.BOOKING_REMINDER);
        notificationRepository.save(notification);
    }
} 