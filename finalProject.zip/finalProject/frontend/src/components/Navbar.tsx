import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';

const Navbar: React.FC = () => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  if (!user) {
    return (
      <nav className="bg-white shadow-lg">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex justify-between h-16">
            <div className="flex items-center">
              <Link to="/" className="text-xl font-bold text-primary-600">
                Vehicle Service
              </Link>
            </div>
            <div className="flex items-center space-x-4">
              <Link to="/login" className="btn-primary">
                Login
              </Link>
              <Link to="/register" className="btn-secondary">
                Register
              </Link>
            </div>
          </div>
        </div>
      </nav>
    );
  }

  return (
    <nav className="bg-white shadow-lg">
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex justify-between h-16">
          <div className="flex items-center">
            <Link to="/dashboard" className="text-xl font-bold text-primary-600">
              Vehicle Service
            </Link>
          </div>
          
          <div className="flex items-center space-x-4">
            <Link to="/dashboard" className="text-gray-700 hover:text-primary-600">
              Dashboard
            </Link>
            <Link to="/booking" className="text-gray-700 hover:text-primary-600">
              Book Service
            </Link>
            <Link to="/vehicles" className="text-gray-700 hover:text-primary-600">
              My Vehicles
            </Link>
            <Link to="/history" className="text-gray-700 hover:text-primary-600">
              Service History
            </Link>
            
            {user.role === 'MECHANIC' && (
              <Link to="/mechanic" className="text-gray-700 hover:text-primary-600">
                Mechanic Portal
              </Link>
            )}
            
            {user.role === 'ADMIN' && (
              <Link to="/admin" className="text-gray-700 hover:text-primary-600">
                Admin Panel
              </Link>
            )}
            
            <div className="flex items-center space-x-2">
              <span className="text-sm text-gray-600">
                Welcome, {user.firstName}
              </span>
              <button
                onClick={handleLogout}
                className="btn-secondary"
              >
                Logout
              </button>
            </div>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar; 