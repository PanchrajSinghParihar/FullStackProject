import React from 'react';

const ServiceHistory: React.FC = () => {
  return (
    <div className="space-y-6">
      <div className="bg-white rounded-lg shadow p-6">
        <h1 className="text-2xl font-bold text-gray-900 mb-4">
          Service History
        </h1>
        <p className="text-gray-600">
          View complete service history and maintenance logs for your vehicles.
        </p>
      </div>
      <div className="bg-white rounded-lg shadow p-6">
        <p className="text-center text-gray-600">
          Service history with feedback and ratings will be implemented here.
        </p>
      </div>
    </div>
  );
};

export default ServiceHistory; 