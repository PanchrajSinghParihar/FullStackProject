#!/bin/bash

echo "🚗 Setting up Vehicle Service Booking System..."

# Check if Node.js is installed
if ! command -v node &> /dev/null; then
    echo "❌ Node.js is not installed. Please install Node.js 18+ first."
    exit 1
fi

# Check if Java is installed
if ! command -v java &> /dev/null; then
    echo "❌ Java is not installed. Please install Java 17+ first."
    exit 1
fi

# Check if MySQL is installed
if ! command -v mysql &> /dev/null; then
    echo "❌ MySQL is not installed. Please install MySQL 8+ first."
    exit 1
fi

echo "✅ Prerequisites check passed"

# Create database
echo "📊 Setting up database..."
mysql -u root -p -e "CREATE DATABASE IF NOT EXISTS vehicle_service_db;"
mysql -u root -p vehicle_service_db < database/schema.sql
mysql -u root -p vehicle_service_db < database/data.sql
echo "✅ Database setup completed"

# Setup backend
echo "🔧 Setting up Spring Boot backend..."
cd backend
if [ ! -d "target" ]; then
    echo "📦 Installing Maven dependencies..."
    mvn clean install -DskipTests
fi
echo "✅ Backend setup completed"
cd ..

# Setup frontend
echo "⚛️ Setting up React frontend..."
cd frontend
if [ ! -d "node_modules" ]; then
    echo "📦 Installing npm dependencies..."
    npm install
fi
echo "✅ Frontend setup completed"
cd ..

echo ""
echo "🎉 Setup completed successfully!"
echo ""
echo "To start the application:"
echo "1. Start the backend: cd backend && mvn spring-boot:run"
echo "2. Start the frontend: cd frontend && npm start"
echo ""
echo "The application will be available at:"
echo "- Frontend: http://localhost:3000"
echo "- Backend API: http://localhost:8080/api"
echo ""
echo "Default login credentials:"
echo "- Customer: john.doe / password123"
echo "- Mechanic: mechanic1 / password123"
echo "- Admin: admin / password123" 