#!/bin/bash

echo "🚗 Starting Vehicle Service Booking System..."

# Start backend in background
echo "🔧 Starting Spring Boot backend..."
cd backend
mvn spring-boot:run &
BACKEND_PID=$!
cd ..

# Wait for backend to start
echo "⏳ Waiting for backend to start..."
sleep 30

# Start frontend
echo "⚛️ Starting React frontend..."
cd frontend
npm start &
FRONTEND_PID=$!
cd ..

echo ""
echo "🎉 Application started successfully!"
echo ""
echo "The application is now running at:"
echo "- Frontend: http://localhost:3000"
echo "- Backend API: http://localhost:8080/api"
echo ""
echo "Press Ctrl+C to stop both services"

# Wait for user to stop
trap "echo '🛑 Stopping services...'; kill $BACKEND_PID $FRONTEND_PID; exit" INT
wait 